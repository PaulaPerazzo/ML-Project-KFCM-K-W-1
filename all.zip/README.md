# ML-Project-KFCM-K-W-1

## Before executing the code:

create a virtual environment:
```
python3 -m venv env
```

and download necessary libs:
```
pip install -r requirements.txt
```